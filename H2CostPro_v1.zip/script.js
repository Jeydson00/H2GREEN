document.addEventListener('DOMContentLoaded', () => {
    // --- Navigation ---
    const navItems = document.querySelectorAll('.nav-item');
    const panes = document.querySelectorAll('.tab-pane');
    const pageTitle = document.getElementById('page-title');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(n => n.classList.remove('active'));
            panes.forEach(p => p.classList.remove('active'));

            item.classList.add('active');
            const target = item.getAttribute('data-tab');
            document.getElementById(target).classList.add('active');
            pageTitle.textContent = item.textContent.trim();
        });
    });

    // --- Modal Logic ---
    const modal = document.getElementById('modal-report');
    const btnDetailed = document.getElementById('btn-detailed-report');
    const spanClose = document.getElementsByClassName("close-modal")[0];

    btnDetailed.onclick = function () {
        modal.style.display = "block";
        generateDetailedReport();
    }

    spanClose.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // --- Tech Selection ---
    const techOptions = document.querySelectorAll('.tech-option');
    const techInput = document.getElementById('tech-type-input');

    // Tech Defaults
    const techDefaults = {
        alkaline: {
            capex: 900,
            efficiency: 50,
            stackLifetime: 80000,
            degradation: 0.12,
            capexNote: "Típico: 800-1000 USD/kW",
            effNote: "Típico: 50-55 kWh/kg"
        },
        pem: {
            capex: 1400,
            efficiency: 48,
            stackLifetime: 50000,
            degradation: 0.20,
            capexNote: "Típico: 1200-1600 USD/kW",
            effNote: "Típico: 45-50 kWh/kg"
        }
    };

    techOptions.forEach(option => {
        option.addEventListener('click', () => {
            techOptions.forEach(o => o.classList.remove('selected'));
            option.classList.add('selected');

            const type = option.getAttribute('data-value');
            techInput.value = type;

            const defaults = techDefaults[type];
            document.getElementById('capex').value = defaults.capex;
            document.getElementById('efficiency').value = defaults.efficiency;
            document.getElementById('stack-lifetime').value = defaults.stackLifetime;
            document.getElementById('degradation-rate').value = defaults.degradation;
            document.getElementById('capex-note').textContent = defaults.capexNote;
            document.getElementById('eff-note').textContent = defaults.effNote;

            runApp();
        });
    });

    // --- Global Data Storage ---
    let currentResults = null;

    // --- Charts Instances ---
    let costChart, comparativeChart, sensitivityChart, annualCostChart, efficiencyChart;

    function initCharts() {
        Chart.defaults.color = '#a6adc8';
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.borderColor = '#45475a';

        // 1. Cost Breakdown
        costChart = new Chart(document.getElementById('costChart').getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['CAPEX', 'OPEX', 'Energia', 'Stack Rep.', 'Outros'],
                datasets: [{
                    data: [0, 0, 0, 0, 0],
                    backgroundColor: ['#89b4fa', '#f38ba8', '#a6e3a1', '#fab387', '#cba6f7'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: true, position: 'right', labels: { boxWidth: 12, color: '#cdd6f4' } } },
                cutout: '65%'
            }
        });

        // 2. Comparative LCOH
        comparativeChart = new Chart(document.getElementById('comparativeChart').getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['H2 Verde', 'H2 Cinza', 'H2 Azul'],
                datasets: [{
                    label: 'LCOH (R$/kg)',
                    data: [0, 0, 0],
                    backgroundColor: ['#a6e3a1', '#a6adc8', '#89b4fa'],
                    borderRadius: 6,
                    barThickness: 40
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });

        // 3. Sensitivity (Tornado)
        sensitivityChart = new Chart(document.getElementById('sensitivityChart').getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['Preço Energia', 'CAPEX', 'WACC', 'OPEX'],
                datasets: [
                    {
                        label: 'Impacto Positivo (+20%)',
                        data: [0, 0, 0, 0],
                        backgroundColor: '#f38ba8',
                        borderRadius: 4
                    },
                    {
                        label: 'Impacto Negativo (-20%)',
                        data: [0, 0, 0, 0],
                        backgroundColor: '#89b4fa',
                        borderRadius: 4
                    }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: { x: { grid: { color: '#45475a' } } }
            }
        });

        // 4. Annual Costs
        annualCostChart = new Chart(document.getElementById('annualCostChart').getContext('2d'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Custo Total (R$ Milhões)',
                    data: [],
                    backgroundColor: '#89b4fa',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true } }
            }
        });

        // 5. Efficiency Curve
        efficiencyChart = new Chart(document.getElementById('efficiencyChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Eficiência (kWh/kg)',
                    data: [],
                    borderColor: '#fab387',
                    tension: 0.4,
                    pointRadius: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { title: { display: true, text: 'kWh/kg' } } }
            }
        });
    }

    // --- Calculation Engine ---

    function getInputs() {
        return {
            electricityPrice: parseFloat(document.getElementById('electricity-price').value),
            capacityFactor: parseFloat(document.getElementById('capacity-factor').value),
            capex: parseFloat(document.getElementById('capex').value),
            efficiency: parseFloat(document.getElementById('efficiency').value),
            waterPrice: parseFloat(document.getElementById('water-price').value),
            waterConsumption: parseFloat(document.getElementById('water-consumption').value),
            stackLifetime: parseFloat(document.getElementById('stack-lifetime').value),
            degradationRate: parseFloat(document.getElementById('degradation-rate').value),
            opexRate: parseFloat(document.getElementById('opex-rate').value),
            stackReplacementCost: parseFloat(document.getElementById('stack-replacement-cost').value),
            discountRate: parseFloat(document.getElementById('discount-rate').value),
            lifetime: parseFloat(document.getElementById('lifetime').value),
            exchangeRate: parseFloat(document.getElementById('exchange-rate').value),
            gridFees: parseFloat(document.getElementById('grid-fees').value),
            electricityTax: parseFloat(document.getElementById('electricity-tax').value),
            oxygenPrice: parseFloat(document.getElementById('oxygen-price').value),
            capexGrant: parseFloat(document.getElementById('capex-grant').value),
            h2Premium: parseFloat(document.getElementById('h2-premium').value),
            natGasPrice: parseFloat(document.getElementById('nat-gas-price').value),
            co2Tax: parseFloat(document.getElementById('co2-tax').value)
        };
    }

    function calculateLCOH(inputs) {
        const exchangeRate = inputs.exchangeRate;
        const discountRate = inputs.discountRate / 100;
        const lifetime = inputs.lifetime;

        const capexUsdKw = inputs.capex;
        const capexBrlKw = capexUsdKw * exchangeRate;
        const capexGrantBrlKw = inputs.capexGrant;
        const netCapexBrlKw = capexBrlKw - capexGrantBrlKw;

        const initialEfficiency = inputs.efficiency;
        const capacityFactor = inputs.capacityFactor / 100;
        const hoursPerYear = 8760 * capacityFactor;

        const totalElecPriceBrlKwh = (inputs.electricityPrice + inputs.gridFees + inputs.electricityTax) / 1000;
        const annualOpexBrlKw = capexBrlKw * (inputs.opexRate / 100);

        const stackLifetimeHours = inputs.stackLifetime;
        const stackReplacementCostPercent = inputs.stackReplacementCost / 100;
        const degradationRate = inputs.degradationRate / 100;

        const waterCostPerKg = (inputs.waterConsumption / 1000) * inputs.waterPrice;
        const oxygenRevenuePerKg = (8 / 1000) * inputs.oxygenPrice;
        const h2PremiumPerKg = inputs.h2Premium;

        let totalNpvCost = 0;
        let totalNpvProduction = 0;

        let npvComponents = { capex: netCapexBrlKw, opex: 0, energy: 0, stack: 0, other: 0 };
        let yearData = [];

        let cumulativeHours = 0;
        let stackReplacementCount = 0;

        // Year 0
        totalNpvCost += netCapexBrlKw;

        for (let year = 1; year <= lifetime; year++) {
            const discountFactor = 1 / Math.pow(1 + discountRate, year);

            // Degradation
            let hoursOnCurrentStack = cumulativeHours % stackLifetimeHours;
            let degStart = (hoursOnCurrentStack / 1000) * degradationRate;
            let degEnd = ((hoursOnCurrentStack + hoursPerYear) / 1000) * degradationRate;
            let avgDeg = (degStart + degEnd) / 2;
            let yearEfficiency = initialEfficiency * (1 + avgDeg);

            let annualEnergyKwh = hoursPerYear;
            let annualH2Kg = annualEnergyKwh / yearEfficiency;

            // Costs
            let yearOpex = annualOpexBrlKw;
            let yearEnergyCost = annualEnergyKwh * totalElecPriceBrlKwh;
            let yearWaterCost = annualH2Kg * waterCostPerKg;

            // Stack Replacement
            let yearStackCost = 0;
            cumulativeHours += hoursPerYear;
            if (cumulativeHours >= (stackReplacementCount + 1) * stackLifetimeHours) {
                yearStackCost = capexBrlKw * stackReplacementCostPercent;
                stackReplacementCount++;
            }

            // Revenues
            let yearRevenues = annualH2Kg * (oxygenRevenuePerKg + h2PremiumPerKg);

            let yearTotalCost = yearOpex + yearEnergyCost + yearStackCost + yearWaterCost - yearRevenues;

            // NPV Accumulation
            totalNpvCost += yearTotalCost * discountFactor;
            totalNpvProduction += annualH2Kg * discountFactor;

            // Components
            npvComponents.opex += yearOpex * discountFactor;
            npvComponents.energy += yearEnergyCost * discountFactor;
            npvComponents.stack += yearStackCost * discountFactor;
            npvComponents.other += (yearWaterCost - yearRevenues) * discountFactor;

            // Store Year Data
            yearData.push({
                year,
                production: annualH2Kg,
                efficiency: yearEfficiency,
                capex: (year === 1 ? netCapexBrlKw : 0), // Visual only
                opex: yearOpex,
                energy: yearEnergyCost,
                stack: yearStackCost,
                other: yearWaterCost - yearRevenues,
                total: yearTotalCost + (year === 1 ? netCapexBrlKw : 0)
            });
        }

        const lcoh = totalNpvCost / totalNpvProduction;

        return { lcoh, npvComponents, totalNpvProduction, yearData };
    }

    function calculateSensitivity(baseInputs, baseLcoh) {
        const factors = ['electricityPrice', 'capex', 'discountRate', 'opexRate'];
        const labels = ['Preço Energia', 'CAPEX', 'WACC', 'OPEX'];
        const variation = 0.20; // 20%

        let positiveImpacts = [];
        let negativeImpacts = [];

        factors.forEach(factor => {
            // High Case (+20% input)
            let inputsHigh = { ...baseInputs };
            inputsHigh[factor] = baseInputs[factor] * (1 + variation);
            let lcohHigh = calculateLCOH(inputsHigh).lcoh;

            // Low Case (-20% input)
            let inputsLow = { ...baseInputs };
            inputsLow[factor] = baseInputs[factor] * (1 - variation);
            let lcohLow = calculateLCOH(inputsLow).lcoh;

            // Calculate Delta from Base LCOH
            // Note: For Costs (Capex, Price), Higher Input = Higher LCOH (Positive Delta)
            // For Efficiency/Lifetime, it might be inverse, but we selected Cost drivers.

            positiveImpacts.push(lcohHigh - baseLcoh);
            negativeImpacts.push(lcohLow - baseLcoh);
        });

        return { labels, positiveImpacts, negativeImpacts };
    }

    function runApp() {
        const inputs = getInputs();
        const results = calculateLCOH(inputs);
        currentResults = results; // Store for modal

        // --- Update UI Numbers ---
        document.getElementById('lcoh-result').textContent = results.lcoh.toFixed(2);
        document.getElementById('lcoh-usd').textContent = (results.lcoh / inputs.exchangeRate).toFixed(2);

        // Grey/Blue Comparison
        const mmbtuPerKgH2 = 0.16;
        const natGasPriceBrl = inputs.natGasPrice * inputs.exchangeRate;
        const lcohGrey = (mmbtuPerKgH2 * natGasPriceBrl) + 2.50;
        const lcohBlue = lcohGrey + ((9 / 1000) * inputs.co2Tax * inputs.exchangeRate) + 1.00;

        const delta = ((results.lcoh - lcohGrey) / lcohGrey) * 100;
        const deltaEl = document.getElementById('delta-green-grey');
        deltaEl.textContent = (delta > 0 ? '+' : '') + delta.toFixed(0) + '%';
        deltaEl.style.color = delta > 0 ? '#f38ba8' : '#a6e3a1';

        // --- Update Charts ---

        // 1. Cost Breakdown
        const c = results.npvComponents;
        const totalProd = results.totalNpvProduction;
        costChart.data.datasets[0].data = [
            c.capex / totalProd,
            c.opex / totalProd,
            c.energy / totalProd,
            c.stack / totalProd,
            Math.max(0, c.other) / totalProd
        ];
        costChart.update();

        // 2. Comparative
        comparativeChart.data.datasets[0].data = [results.lcoh, lcohGrey, lcohBlue];
        comparativeChart.update();

        // 3. Sensitivity
        const sens = calculateSensitivity(inputs, results.lcoh);
        sensitivityChart.data.datasets[0].data = sens.positiveImpacts;
        sensitivityChart.data.datasets[1].data = sens.negativeImpacts;
        sensitivityChart.update();

        // 4. Annual Costs
        annualCostChart.data.labels = results.yearData.map(d => `Ano ${d.year}`);
        annualCostChart.data.datasets[0].data = results.yearData.map(d => d.total / 1000000); // Millions
        annualCostChart.update();

        // 5. Efficiency Curve
        efficiencyChart.data.labels = results.yearData.map(d => `Ano ${d.year}`);
        efficiencyChart.data.datasets[0].data = results.yearData.map(d => d.efficiency);
        efficiencyChart.update();
    }

    function generateDetailedReport() {
        if (!currentResults) return;
        const tbody = document.querySelector('#report-table tbody');
        tbody.innerHTML = '';

        currentResults.yearData.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${row.year}</td>
                <td>${Math.round(row.production).toLocaleString()}</td>
                <td>${row.efficiency.toFixed(2)}</td>
                <td>${Math.round(row.capex).toLocaleString()}</td>
                <td>${Math.round(row.opex).toLocaleString()}</td>
                <td>${Math.round(row.energy).toLocaleString()}</td>
                <td>${Math.round(row.stack).toLocaleString()}</td>
                <td>${Math.round(row.other).toLocaleString()}</td>
                <td><strong>${Math.round(row.total).toLocaleString()}</strong></td>
            `;
            tbody.appendChild(tr);
        });
    }

    // Event Listeners
    const allInputs = document.querySelectorAll('input');
    allInputs.forEach(input => {
        input.addEventListener('input', runApp);
    });

    // Init
    initCharts();
    runApp();
});
